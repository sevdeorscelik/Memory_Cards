export const users = [
	{
		"id": 1,
		"firstName": "Sevde",
		"lastName": "Örscelik",
		"mail": "sevdeorscelik@gmail.com",
		"password": "0301",
	}
];
