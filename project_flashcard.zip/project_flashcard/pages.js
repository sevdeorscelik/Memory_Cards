export const pages = [
	{
		"id": 1,
		"idCode": "home",
		"title": "Home",
	},
	{
		"id": 2,
		"idCode": "login",
		"title": "Login",
    }
]